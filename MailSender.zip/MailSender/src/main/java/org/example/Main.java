package org.example;


import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class CsvToMailWithAttachment {

    public static void main(String[] args) {
        String csvFilePath = "src/main/resources/emails.csv"; // CSV dosyasının yolu
        String attachmentFilePath = "path/to/your/attachment"; // Eklenecek dosyanın yolu
        List<String> toEmails = new ArrayList<>();
        List<String> ccEmails = new ArrayList<>();

        readEmailsFromCsv(csvFilePath, toEmails, ccEmails);

        if (!toEmails.isEmpty()) {
            sendBulkEmailWithAttachment(toEmails, ccEmails, "Test Bulk Email", "This is a test email sent in bulk.", attachmentFilePath);
        }
    }

    private static void readEmailsFromCsv(String filePath, List<String> toEmails, List<String> ccEmails) {
        try (BufferedReader reader = Files.newBufferedReader(Paths.get(filePath));
             CSVParser csvParser = new CSVParser(reader, CSVFormat.DEFAULT)) {

            int rowNum = 0;
            for (CSVRecord csvRecord : csvParser) {
                if (rowNum == 0) {
                    csvRecord.forEach(toEmails::add);
                } else if (rowNum == 1) {
                    csvRecord.forEach(ccEmails::add);
                }
                rowNum++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void sendBulkEmailWithAttachment(List<String> toEmails, List<String> ccEmails, String subject, String content, String attachmentFilePath) {
        String host = "smtp.example.com";
        String port = "587";
        String username = "your-email@example.com";
        String password = "your-email-password";

        Properties properties = new Properties();
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", port);

        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(username));
            message.setRecipients(Message.RecipientType.TO, toEmails.stream().map(email -> {
                try {
                    return new InternetAddress(email);
                } catch (AddressException e) {
                    e.printStackTrace();
                    return null;
                }
            }).toArray(InternetAddress[]::new));
            message.setRecipients(Message.RecipientType.CC, ccEmails.stream().map(email -> {
                try {
                    return new InternetAddress(email);
                } catch (AddressException e) {
                    e.printStackTrace();
                    return null;
                }
            }).toArray(InternetAddress[]::new));
            message.setSubject(subject);

            // Email content
            MimeBodyPart messageBodyPart = new MimeBodyPart();
            messageBodyPart.setText(content);

            // Attachment
            MimeBodyPart attachmentBodyPart = new MimeBodyPart();
            attachmentBodyPart.attachFile(attachmentFilePath);

            Multipart multipart = new MimeMultipart();
            multipart.addBodyPart(messageBodyPart);
            multipart.addBodyPart(attachmentBodyPart);

            message.setContent(multipart);

            Transport.send(message);
            System.out.println("Email sent successfully to: " + toEmails + " with CC: " + ccEmails);
        } catch (MessagingException | IOException e) {
            e.printStackTrace();
        }
    }
}


